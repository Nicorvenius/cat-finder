export const environment = {
  production: true,
  apiKey: 'live_nOGcdayZusg60BGZZvwgWr5TEh96MQhJlRoHbGERoDiHoN3j6Qb8UfUcsY8vaUcu',
  apiUrl: 'https://api.thecatapi.com'
};
