export const environment = {
  production: false,
  apiKey: 'live_nOGcdayZusg60BGZZvwgWr5TEh96MQhJlRoHbGERoDiHoN3j6Qb8UfUcsY8vaUcu',
  apiUrl: 'https://api.thecatapi.com'
};
