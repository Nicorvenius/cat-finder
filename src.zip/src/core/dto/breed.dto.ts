export class CatBreedDTO {
  id!: number;
  name!: string;
}
